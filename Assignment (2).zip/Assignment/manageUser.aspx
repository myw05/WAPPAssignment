﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="manageUser.aspx.cs" Inherits="Assignment.manageUser" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <link href="backgroundstyle.css" rel="stylesheet" type="text/css" />
    <link href="hbtnlayout.css" rel="stylesheet" type="text/css" />
    <style type="text/css">
        .auto-style1 {
            width: 100%;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="container">
            <div class="header-container">
                <img src="Smartvent.jpg" alt="Smart Venture Logo" class="logo-img" />
                <div class="header-text">
                    <h1>Smart Venture</h1>
                    <p>Let's edit the accounts</p>
                </div>
            </div>
       </div>
        <div style="text-align: right; margin: 10px 20px;">
            <asp:Button ID="HomeButton" runat="server" Text="Home" OnClick="HomeButton_Click" CssClass="btn-home" />
        </div>
        <div class="page-box">
            <h2>Manage User</h2>
            <p>
                <asp:Label ID="svfName" runat="server" Text="Label"></asp:Label>
            </p>
            <div class="form-group">
                
                <table class="auto-style1">
                    <tr>
                        <td>
                            <asp:Label ID="lblrole" runat="server" Text="Role"></asp:Label>
                        </td>
                        <td>
                            <asp:DropDownList ID="role" runat="server" AutoPostBack="true" OnSelectedIndexChanged="role_SelectedIndexChanged">
                                <asp:ListItem>Admin</asp:ListItem>
                                <asp:ListItem>Teacher</asp:ListItem>
                                <asp:ListItem>Student</asp:ListItem>
                            </asp:DropDownList>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <asp:Label ID="Label2" runat="server" Text="Username"></asp:Label>
                        </td>
                        <td>
                            <asp:DropDownList ID="username" runat="server" AutoPostBack="True" OnSelectedIndexChanged="username_SelectedIndexChanged" >
                                <asp:ListItem></asp:ListItem>
                            </asp:DropDownList>

                            
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <asp:Label ID="Label3" runat="server" Text="First Name:"></asp:Label>
                        </td>
                        <td>
                            <asp:TextBox ID="fname" runat="server"></asp:TextBox>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <asp:Label ID="lbl" runat="server" Text="Last Name:"></asp:Label>
                        </td>
                        <td>
                            <asp:TextBox ID="lname" runat="server"></asp:TextBox>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <asp:Label ID="gender" runat="server" Text="Gender"></asp:Label>
                        </td>
                        <td>
                            <asp:DropDownList ID="DropDownList1" runat="server">
                                <asp:ListItem>Rather Not To Say</asp:ListItem>
                                <asp:ListItem>F</asp:ListItem>
                                <asp:ListItem>M</asp:ListItem>
                            </asp:DropDownList>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <asp:Label ID="Label6" runat="server" Text="Age"></asp:Label>
                        </td>
                        <td>
                            <asp:TextBox ID="age" runat="server"></asp:TextBox>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <asp:Label ID="Label9" runat="server" Text="Email: "></asp:Label>
                        </td>
                        <td>
                            <asp:TextBox ID="email" runat="server"></asp:TextBox>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <asp:Label ID="lblpwd" runat="server" Text="Password"></asp:Label>
                        </td>
                        <td>
                            <asp:TextBox ID="password" runat="server"></asp:TextBox>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <asp:Label ID="Label8" runat="server" Text="Confrim Password"></asp:Label>
                        </td>
                        <td>
                            <asp:TextBox ID="confirmpassword" runat="server"></asp:TextBox>
                        </td>
                    </tr>
                </table>
                
            </div>            
          
             <div>
                 <asp:Button ID="Button1" runat="server" Text="Update" CssClass="btn" OnClick="Button1_Click" />
                 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                 <asp:Button ID="Button3" runat="server" Text="Delete" CssClass="btn" OnClick="Button2_Click" />
             </div>
             <div>

                 <asp:Label ID="errMsg" runat="server" ForeColor="Red" Text="errMsg"></asp:Label>

             </div>
         </div>

    <footer>
        <p>&copy; 2025 Smart Venture. All rights reserved.</p>
    </footer>
   
    </form>
</body>
</html>
