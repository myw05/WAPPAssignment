﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment
{
	public partial class proceed : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (yesbtn.Checked)
            {
                Response.Redirect("login.aspx");
            }
            else if (nobtn.Checked)
            {
                Response.Redirect("Welcomepage.aspx");
            }
            else
            {
                errMsg.Text = "Please select an option before proceeding.";
                errMsg.ForeColor = System.Drawing.Color.Red;
                errMsg.Visible = true;
            }
        }

        
    }
}