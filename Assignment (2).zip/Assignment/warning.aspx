﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="warning.aspx.cs" Inherits="Assignment.warning" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <link href="backgroundstyle.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <form id="form1" runat="server">
        <div class="container">
            <div class="header-container">
                <img src="Smartvent.jpg" alt="Smart Venture Logo" class="logo-img" />
                <div class="header-text">
                    <h1>Smart Venture</h1>
                    <p>Oops! Yous have an error.</p>
                </div>
            </div>
        </div>

        <div class="page-box">
            <h2>Access Denied</h2>
            <p>You must be logged in to access this page.</p>            
            <asp:Button ID="Button1" runat="server" Text="Log In" OnClick="Button1_Click" />
        </div>  
            
        <div>
            <footer>
                <p>&copy; 2025 Smart Venture. All rights reserved.</p>
            </footer>
        </div>
    </form>
</body>
</html>
