﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI;
using System.Xml.Linq;

namespace Assignment
{
    public partial class EditProfile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["username"] == null)
            {
                Response.Redirect("Login.aspx");
                return;
            }

            if (!IsPostBack)
            {
                LoadUserData();
            }
        }

        private void LoadUserData()
        {
            string username = Session["username"].ToString();
            string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            string query = "SELECT * FROM accountTable WHERE username = @username";

            using (SqlConnection conn = new SqlConnection(connStr))
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@username", username);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    fname.Text = reader["fname"].ToString();
                    lname.Text = reader["lname"].ToString();
                    gender.Text = reader["gender"].ToString();
                    age.Text = reader["age"].ToString();
                    email.Text = reader["email"].ToString();
                    password.Text = reader["password"].ToString();
                    confirmpassword.Text = reader["confirmpassword"].ToString();
                }
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (password.Text != confirmpassword.Text)
            {
                errMsg.Visible = true;
                errMsg.ForeColor = System.Drawing.Color.Red;
                errMsg.Text = "Password and Confirm-password does not match.";
                return;
            }

            string username = Session["username"].ToString();
            string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            string query = @"UPDATE accountTable SET 
                                fname = @fname, lname = @lname, gender = @gender, age = @age, 
                                email = @email, password = @password, confirmpassword = @confirmpassword 
                                WHERE username = @username";

            using (SqlConnection conn = new SqlConnection(connStr))
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@fname", fname.Text);
                cmd.Parameters.AddWithValue("@lname", lname.Text);
                cmd.Parameters.AddWithValue("@gender", gender.Text);
                cmd.Parameters.AddWithValue("@age", age.Text);
                cmd.Parameters.AddWithValue("@email", email.Text);
                cmd.Parameters.AddWithValue("@password", password.Text);
                cmd.Parameters.AddWithValue("@confirmpassword", confirmpassword.Text);
                cmd.Parameters.AddWithValue("@username", username);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            errMsg.Visible = false;

            if (string.IsNullOrWhiteSpace(fname.Text) ||
                string.IsNullOrWhiteSpace(lname.Text) ||
                string.IsNullOrWhiteSpace(age.Text) ||
                string.IsNullOrWhiteSpace(email.Text) ||
                string.IsNullOrWhiteSpace(gender.Text) ||
                string.IsNullOrWhiteSpace(password.Text) ||
                string.IsNullOrWhiteSpace(confirmpassword.Text))
            {
                errMsg.Text = "All fields must be filled.";
                errMsg.ForeColor = System.Drawing.Color.Red;
                errMsg.Visible = true;
                return;
            }

            if (password.Text != confirmpassword.Text)
            {
                errMsg.Text = "Password and Confirm-password do not match.";
                errMsg.ForeColor = System.Drawing.Color.Red;
                errMsg.Visible = true;
                return;
            }

            string username = Session["username"].ToString();
            string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string query = @"UPDATE accountTable 
                         SET fname = @fname, lname = @lname, gender = @gender, age = @age, 
                             email = @email, password = @password, confirmpassword = @confirmpassword
                         WHERE username = @username";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@fname", fname.Text);
                cmd.Parameters.AddWithValue("@lname", lname.Text);
                cmd.Parameters.AddWithValue("@gender", gender.Text);
                cmd.Parameters.AddWithValue("@age", age.Text);
                cmd.Parameters.AddWithValue("@email", email.Text);
                cmd.Parameters.AddWithValue("@password", password.Text);
                cmd.Parameters.AddWithValue("@confirmpassword", confirmpassword.Text);
                cmd.Parameters.AddWithValue("@username", username);

                cmd.ExecuteNonQuery();
            }

            errMsg.Text = "Profile successfully updated.";
            errMsg.ForeColor = System.Drawing.Color.Green;
            errMsg.Visible = true;

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Welcomepage.aspx");
        }
    }
    
}
