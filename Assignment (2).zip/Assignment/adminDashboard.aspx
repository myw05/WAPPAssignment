﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="adminDashboard.aspx.cs" Inherits="Assignment.adminDashboard" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Admin Dashboard</title>
    <link href="backgroundstyle.css" rel="stylesheet" type="text/css" />
    <style type="text/css">
        .auto-style1 {
            text-align: left;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
    <div class="container">
        <div class="header-container">
            <img src="Smartvent.jpg" alt="Smart Venture Logo" class="logo-img" />
            <div class="header-text">
                <h1>Smart Venture Admin</h1>                
            </div>
        </div>              

        <div class="page-box" style="margin-top: 100px;">
            <h2>
                <asp:Label ID="wlcname" runat="server" Text="Label"></asp:Label>
            </h2>
            <div class="form-group">
                <label for="user-stats">User Statistics</label>
                <asp:TextBox ID="UserStatsTextBox" runat="server" CssClass="form-control" ReadOnly="true" />

                <br />
            </div>
            <div >

                <asp:Button ID="Button1" runat="server" Text="Manage Users" class="submit-btn" OnClick="Button1_Click" />
                <br /><br />
                <asp:Button ID="Button2" runat="server" Text="Dashboard" class="submit-btn" OnClick="Button2_Click" />
                <br /><br />
                <asp:Button ID="Button3" runat="server" Text="Log Out" class="submit-btn"  OnClick="Button3_Click" />
                <br />
                <br /><br />
                <asp:Button ID="Button4" runat="server" Text="Edit Profile" class="submit-btn"  OnClick="Button4_Click" />
                <br />

            </div>
        </div>
        <footer>
            <p>&copy; 2025 Smart Venture. All rights reserved.</p>
        </footer>        
    </div>

    </form>

</body>
</html>