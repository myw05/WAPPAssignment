﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="EditProfile.aspx.cs" Inherits="Assignment.EditProfile" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">

    <title>Edit Profile</title>
    <link href="backgroundstyle.css" rel="stylesheet" type="text/css" />
    <style type="text/css">
        .auto-style1 {
            font-family: Poppins, sans-serif;
            font-weight: 500;
            font-size: 18px;
            color: #FFFFFF;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="container">
            <header>
                <h1>Edit Your Profile</h1>
                <p>Update your information below</p>
            </header>

            <div class="page-box">
                <h2>Personal Details</h2>

                <div class="form-group">
                    <label>First Name</label>
                    <asp:TextBox ID="fname" runat="server" CssClass="form-control" />
                </div>

                <div class="form-group">
                    <label>Last Name</label>
                    <asp:TextBox ID="lname" runat="server" CssClass="form-control" />
                </div>

                <div class="form-group">
                    <label>Gender</label>
                    <asp:TextBox ID="gender" runat="server" CssClass="form-control" />
                </div>

                <div class="form-group">
                    <label>Age</label>
                    <asp:TextBox ID="age" runat="server" CssClass="form-control" />
                </div>

                <div class="form-group">
                    <label>Email</label>
                    <asp:TextBox ID="email" runat="server" CssClass="form-control" />
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <asp:TextBox ID="password" runat="server" CssClass="form-control" TextMode="Password" />
                </div>

                <div class="form-group">
                    <label>Confirm Password</label>
                    <asp:TextBox ID="confirmpassword" runat="server" CssClass="form-control" TextMode="Password" />
                </div>

                <div>
                    <asp:Button ID="Button1" runat="server" Text="Update"  OnClick="Button1_Click" />
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <asp:Button ID="Button2" runat="server" Text="Back"  OnClick="Button2_Click" />
                </div>

                <div>

                    <asp:Label ID="errMsg" runat="server" ForeColor="Red" Text="errMsg"></asp:Label>

                </div>


            <footer>
                &copy; 2025 Smart Venture | All Rights Reserved
            </footer>
        </div>
    </form>
</body>
</html>