﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment
{
	public partial class Registeration : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}

        protected void Signup_Click(object sender, EventArgs e)
        {
            
            if (string.IsNullOrWhiteSpace(fname.Text) ||
                string.IsNullOrWhiteSpace(lname.Text) ||
                string.IsNullOrWhiteSpace(age.Text) ||
                string.IsNullOrWhiteSpace(email.Text) ||
                string.IsNullOrWhiteSpace(gender.Text) ||
                string.IsNullOrWhiteSpace(username.Text) ||
                string.IsNullOrWhiteSpace(password.Text) ||              
                string.IsNullOrWhiteSpace(confirmpassword.Text))
            {
                errMsg.Text = "All fields must be filled.";
                errMsg.Visible = true;
                return;
            }

            if (password.Text != confirmpassword.Text)
            {
                errMsg.Text = "Password and Confirm Password does not match.";
                errMsg.Visible = true;
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString))
                {
                    con.Open();

                    // Check if username already exists
                    SqlCommand checkUser = new SqlCommand("SELECT COUNT(*) FROM accountTable WHERE username = @username", con);
                    checkUser.Parameters.AddWithValue("@username", username.Text);
                    int userExists = (int)checkUser.ExecuteScalar();

                    if (userExists > 0)
                    {
                        errMsg.Text = "Username has been taken!";
                        errMsg.Visible = true;
                        return;
                    }

                    // Insert new user
                    SqlCommand insert = new SqlCommand("INSERT INTO accountTable (fname, lname, gender, age, email, username, password, confirmpassword, role) VALUES (@fname, @lname, @gender, @age, @email, @username, @password, @confirmpassword, @role)", con);
                    insert.Parameters.AddWithValue("@fname", fname.Text);
                    insert.Parameters.AddWithValue("@lname", lname.Text);
                    insert.Parameters.AddWithValue("@gender", gender.SelectedItem.Text);
                    insert.Parameters.AddWithValue("@age", int.Parse(age.SelectedItem.Text));
                    insert.Parameters.AddWithValue("@email", email.Text);
                    insert.Parameters.AddWithValue("@username", username.Text);
                    insert.Parameters.AddWithValue("@password", password.Text); // Consider hashing in production
                    insert.Parameters.AddWithValue("@confirmpassword", confirmpassword.Text);
                    insert.Parameters.AddWithValue("@role", role.SelectedItem.Text);

                    insert.ExecuteNonQuery();
                    Response.Redirect("proceed.aspx");
                }
            }
            catch
            {
                errMsg.Text = "Registration failed due to a server error.";
                errMsg.Visible = true;
            }
        }
    }
}