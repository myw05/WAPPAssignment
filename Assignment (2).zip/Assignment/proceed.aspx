﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="proceed.aspx.cs" Inherits="Assignment.proceed" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <link href="backgroundstyle.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <form id="form1" runat="server">
       <div class="page-box">
            <h2>Registration Successful</h2>
            <div class="form-group">
                <asp:Label ID="Label1" runat="server" Text="Thank you for registering!"></asp:Label>
            </div>

            <div class="form-group">
                <asp:Label ID="Label2" runat="server" Text="Do you want to proceed with login?"></asp:Label>
                <br />
            </div>
            <div text-align="left">

                <asp:RadioButton ID="yesbtn" runat="server" Text="Yes" GroupName="loginChoice" AutoPostBack="false"/>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <asp:RadioButton ID="nobtn" runat="server" Text="No" GroupName="loginChoice" AutoPostBack="false" />

            </div>
            <br />
            <div class="form-group">
                <asp:Button ID="Button1" runat="server" Text="Submit" CssClass="submit-btn" OnClick="Button1_Click" />
            </div>

            <asp:Label ID="errMsg" runat="server" Visible="false" />
            
        </div>
        <footer>
            &copy; 2025 Smart Venture
        </footer>
    </form>
</body>
</html>
