﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace Assignment
{
	public partial class manageUser : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (Session["FirstName"] != null)
			{ 
			
				svfName.Text = "Hi," + Session["FirstName"].ToString();
			}
            else
            {
                Response.Redirect("login.aspx");
            }

			SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
			con.Open();

            if (!IsPostBack)
            {
                // 1. Bind the role dropdown FIRST
                SqlDataAdapter roleAdapter = new SqlDataAdapter("SELECT DISTINCT role FROM accountTable", con);
                DataTable roleDt = new DataTable();
                roleAdapter.Fill(roleDt);

                role.DataSource = roleDt;
                role.DataTextField = "role";
                role.DataValueField = "role";
                role.DataBind();

                SqlDataAdapter userAdapter = new SqlDataAdapter("SELECT username FROM accountTable", con);
                DataTable userDt = new DataTable();
                userAdapter.Fill(userDt);

                username.DataSource = userDt;
                username.DataTextField = "username";
                username.DataValueField = "username";
                username.DataBind();

                // 2. Read the username from querystring
                string selectedUsername = Request.QueryString["username"];

                if (!string.IsNullOrEmpty(selectedUsername))
                {
                    // 3. Load the user info AFTER binding dropdowns
                    LoadUserDetails(selectedUsername, con);
                }

                con.Close();
            }
        }
    



       

        protected void role_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearForm();
            
            string selectedRole = role.SelectedValue;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            con.Open();

            SqlCommand cmd = new SqlCommand("SELECT username FROM accountTable WHERE role = @role", con);
            cmd.Parameters.AddWithValue("@role", selectedRole);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            username.DataSource = dt;
            username.DataTextField = "username";
            username.DataValueField = "username";
            username.DataBind();

            con.Close();

        }

        protected void username_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearForm();
            string selectedUser = username.SelectedValue;

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            con.Open();

            SqlCommand cmd = new SqlCommand("SELECT * FROM accountTable WHERE username = @username", con);
            cmd.Parameters.AddWithValue("@username", selectedUser);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                fname.Text = dt.Rows[0]["fname"].ToString();
                lname.Text = dt.Rows[0]["lname"].ToString();
                gender.Text = dt.Rows[0]["gender"].ToString();
                age.Text = dt.Rows[0]["age"].ToString();
                email.Text = dt.Rows[0]["email"].ToString();
                password.Text = dt.Rows[0]["password"].ToString();
                confirmpassword.Text = dt.Rows[0]["confirmpassword"].ToString();
            }

            con.Close();
        }


        protected void Button1_Click(object sender, EventArgs e)
        {
            errMsg.Visible = false;
            if (string.IsNullOrWhiteSpace(fname.Text) ||
                string.IsNullOrWhiteSpace(lname.Text) ||
                string.IsNullOrWhiteSpace(age.Text) ||
                string.IsNullOrWhiteSpace(email.Text) ||
                string.IsNullOrWhiteSpace(gender.Text) ||
                string.IsNullOrWhiteSpace(username.Text) ||
                string.IsNullOrWhiteSpace(password.Text) ||
                string.IsNullOrWhiteSpace(confirmpassword.Text))
            {
                errMsg.Text = "All fields must be filled.";
                errMsg.ForeColor = System.Drawing.Color.Red;
                errMsg.Visible = true;
                return;
            }
            else
            {
                errMsg.Text = "Successfully Updated.";
                errMsg.ForeColor = System.Drawing.Color.Green;
                errMsg.Visible = true;
                return;
            }

                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString))
                {
                    con.Open();

                    string query = @"UPDATE accountTable 
                         SET fname = @fname, 
                             lname = @lname, 
                             gender = @gender, 
                             age = @age, 
                             email = @email, 
                             password = @password,
                             confirmpassword = @confirmpassword,
                             role = @role 
                         WHERE username = @username";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@fname", fname.Text);
                    cmd.Parameters.AddWithValue("@lname", lname.Text);
                    cmd.Parameters.AddWithValue("@gender", gender.Text);
                    cmd.Parameters.AddWithValue("@age", age.Text);
                    cmd.Parameters.AddWithValue("@email", email.Text);
                    cmd.Parameters.AddWithValue("@password", password.Text);
                    cmd.Parameters.AddWithValue("@confirmpassword", confirmpassword.Text);
                    cmd.Parameters.AddWithValue("@role", role.Text);
                    cmd.Parameters.AddWithValue("@username", username.SelectedValue); 

                    cmd.ExecuteNonQuery();
                }

            Response.Redirect("manageUser.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString))
            {
                con.Open();
                string query = "DELETE FROM accountTable WHERE username = @username";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@username", username.Text);
                cmd.ExecuteNonQuery();
                ClearForm();
                errMsg.Text = "Successfully Deleted.";
                errMsg.ForeColor = System.Drawing.Color.Green;
                errMsg.Visible = true;
                return;
            }
            Response.Redirect("manageUser.aspx");
            
        }

        private void ClearForm()
        {
            fname.Text = "";
            lname.Text = "";
            gender.Text = "";
            age.Text = "";
            email.Text = "";
            password.Text = "";
            confirmpassword.Text = "";
        }

        private void LoadUserDetails(string selectedUser, SqlConnection con)
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM accountTable WHERE username = @username", con);
            cmd.Parameters.AddWithValue("@username", selectedUser);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                fname.Text = dt.Rows[0]["fname"].ToString();
                lname.Text = dt.Rows[0]["lname"].ToString();
                DropDownList1.SelectedValue = dt.Rows[0]["gender"].ToString(); // assuming DropDownList1 is for gender
                age.Text = dt.Rows[0]["age"].ToString();
                email.Text = dt.Rows[0]["email"].ToString();
                password.Text = dt.Rows[0]["password"].ToString();
                confirmpassword.Text = dt.Rows[0]["confirmpassword"].ToString();
                role.SelectedValue = dt.Rows[0]["role"].ToString();
            }
        }

        protected void HomeButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminDashboard.aspx");
        }
    }
}
