﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI;

namespace Assignment
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT fname, role FROM accountTable WHERE username = @username AND password = @password", con);
                cmd.Parameters.AddWithValue("@username", username.Text.Trim());
                cmd.Parameters.AddWithValue("@password", password.Text.Trim());

                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    string name = dr["fname"].ToString().Trim();
                    string role = dr["role"].ToString().Trim();

                    Session["firstname"] = name;
                    Session["username"] = username.Text.Trim(); 

                    switch (role)
                    {
                        case "Admin":
                            Response.Redirect("adminDashboard.aspx");
                            break;
                        case "Teacher":
                            Response.Redirect("Teacher.aspx");
                            break;
                        case "Student":
                            Response.Redirect("Student.aspx");
                            break;
                        default:
                            errMsg.Visible = true;
                            errMsg.Text = "Invalid role.";
                            break;
                    }
                }
                else
                {
                    errMsg.Visible = true;
                    errMsg.ForeColor = System.Drawing.Color.Red;
                    errMsg.Text = "Username or password is incorrect.";
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Registration.aspx");
        }
    }
}
