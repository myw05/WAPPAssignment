﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment
{
	public partial class adminDashboard : System.Web.UI.Page
	{
	    protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["FirstName"] != null)
            {
                wlcname.Text = "Welcome, " + Session["FirstName"].ToString();
            }
            else
            {
                Response.Redirect("login.aspx");
            }

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            con.Open();

            if (!Page.IsPostBack)
            {
                // Count how many usernames
                SqlCommand countCmd = new SqlCommand("SELECT COUNT(username) FROM accountTable", con);
                int totalUsers = (int)countCmd.ExecuteScalar();
                UserStatsTextBox.Text = "Total Users: " + totalUsers.ToString();
            }

            con.Close();        
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("manageUser.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("adminDashboard2.aspx");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Request.Cookies.Clear();

            Response.Redirect("login.aspx");
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("EditProfile.aspx");
        }
    }
}