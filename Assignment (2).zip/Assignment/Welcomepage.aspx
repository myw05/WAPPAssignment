﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Welcomepage.aspx.cs" Inherits="Assignment.Welcomepage" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Online E-Learning Class For Secondary Student</title>
    <link href="design.css" rel="stylesheet" type="text/css" />
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #e0f7fa, #b2ebf2);
        }

        .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 60px;
            max-width: 1350px;
            margin: auto;
        }

        .text-content {
            max-width: 600px;
        }

        .title-box {
            background-color: #00695c;
            color: white;
            display: inline-block;
            padding: 6px 12px;
            border-radius: 6px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        h1 {
            font-size: 48px;
            margin: 0;
        }

        p {
            font-size: 16px;
            color: #333;
            margin: 20px 0;
        }

        .btn {
            background-color: #00695c;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 30px;
            cursor: pointer;
            text-decoration: none;
            font-size: 16px;
        }

        .btn:hover {
            background: #00796b;
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 137, 123, 0.15);
        }

        .image-circle {
            border-radius: 50%;
            overflow: hidden;
            width: 300px;
            height: 300px;
        }

        .image-circle img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .name {
            font-size: 22px;
            font-weight: bold;
            color: #00695c;
        }

        @media (max-width: 768px) {
            .container {
                flex-direction: column;
                text-align: center;
            }

            .image-circle {
                margin-top: 30px;
            }
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
      <div class="header">
          <img src="Smartvent.jpg" alt="Smart Venture Logo" class="logo-img" />
        <div class="name">Smart Venture</div>
        <nav class="nav-links">
            <asp:HyperLink ID="HyperLink1" runat="server">Home</asp:HyperLink>
            <asp:HyperLink ID="HyperLink2" runat="server">About Us</asp:HyperLink>
            <asp:HyperLink ID="HyperLink3" runat="server">Contact Us</asp:HyperLink>
            &nbsp;
            <asp:Button ID="Button1" runat="server" Text="Log In" class="btn " OnClick="Button1_Click"/>
            &nbsp;
            <asp:Button ID="Button4" runat="server" Text="Register" CssClass="btn" OnClick="Button4_Click"/>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        </nav>
      </div>
        <div class="container">
            <div class="text-content">
                <br />
                <br />
                <br />
                <div class="title-box">Online</div>
                <h1>E-Learning<br />Class For Kids</h1>
                <p>Learn all concepts regarding to mathematics in a fun environment that includes a variety of videos, quiz and exam.</p>
                <asp:Button ID="Button2" runat="server" Text="Let's Go" class="btn " OnClick="Button2_Click"/>
            </div>

             
        </div>
        <div class="footer">
            <p>&copy; 2025 Smart Venture. All rights reserved.</p>
        </div>
    </form>
</body>
</html>