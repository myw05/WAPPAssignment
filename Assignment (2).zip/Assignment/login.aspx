﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="login.aspx.cs" Inherits="Assignment.login" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
        <link href="backgroundstyle.css" rel="stylesheet" type="text/css" />
        <style>       


            .forgot-password {
                display: block;
                text-align: right;
                margin-top: 8px;
                font-size: 15px;
                color: #00897b;
                text-decoration: none;
            }
         </style>

 
</head>
<body>
    <form id="form1" runat="server">
        <div class="container">
            <div class="header-container">
                <img src="Smartvent.jpg" alt="Smart Venture Logo" class="logo-img" />
                <div class="header-text">
                    <h1>Smart Venture</h1>
                    <p>Welcome back! Please log in to continue.</p>
                </div>
            </div>

        <div class="page-box">
            <h2>Login to Smart Venture</h2>
            <div class="form-group">
                <label for="txtEmail">Username</label>
                <asp:TextBox ID="username" runat="server" CssClass="form-control" placeholder="Enter your username"></asp:TextBox>
            </div>
            <div class="form-group">
                <label for="txtPassword">Password</label>
                <asp:TextBox ID="password" runat="server" TextMode="Password" CssClass="form-control" placeholder="Enter your password"></asp:TextBox>
            </div>
            <asp:Button ID="btnLogin" runat="server" Text="Login" CssClass="submit-btn" OnClick="btnLogin_Click" />
            <div>

                <asp:Label ID="errMsg" runat="server" ForeColor="Red" text-align="left"></asp:Label>

            </div>
        </div>
    
        <br/>
    <div>
       
        <asp:Label ID="Label1" runat="server" Text="Don't have an account? "></asp:Label>
&nbsp;&nbsp;
            <asp:Button ID="Button1" runat="server" Text="Sign Up" CssClass="button" OnClick="Button1_Click" />
    </div>

    <footer>
        <p>&copy; 2025 Smart Venture. All rights reserved.</p>
    </footer>
</div>
    </form>
</body>
</html>
