﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="adminDashboard2.aspx.cs" Inherits="Assignment.adminDashboard2" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Admin Dashboard</title>

    <style>
        .background {
            background: linear-gradient(to right, #e0f7fa, #b2ebf2);            
            min-height: 100vh;
        }

        h2 {
            color: #00796b;
            font-weight: 600;
            margin-bottom: 30px;
            font-size: 32px;
            text-align: center;
            letter-spacing: 1px;
        }


        .logo-img {
            width: 105px;
            height: 65px;
            border-radius: 16px;
            margin-bottom: 15px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            transition: transform 0.3s ease;
        }

            .logo-img:hover {
                transform: scale(1.05); 
            }


        .header, .footer {
            position: fixed;
            width: 100%;
            background-color: #ffffffcc;
            display: flex;    
            align-items: center;
            padding: 15px 50px;
            backdrop-filter: blur(8px);
            z-index: 1000;
        }

        .header {
            top: 0;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            justify-content:flex-start; 
        }

        .footer {
            bottom: 0;
            box-shadow: 0 -4px 10px rgba(0, 0, 0, 0.1);
            justify-content: center; 
        }

        .dashboard-box {
            display: flex;
            justify-content: space-around;
            margin: 20px 0;
        }

                        .stat {
                            background-color: #00695c;
                            border-radius: 10px;
                            padding: 20px;
                            width: 200px;
                            text-align: center;
                            box-shadow: 2px 2px 5px gray;
                        }

        .grid-style {
            margin: 30px auto;
            width: 95%;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            font-size: 18px; /* bigger text */
            border-radius: 10px;
            overflow: hidden;
        }

        .table th, .table td {
            border: 1px solid #ccc;
            padding: 18px 14px; /* more padding */
            text-align: center;
            min-width: 120px;
        }

        .table th {
            background-color: #00695c;
            color: white;
            font-size: 19px;
        }

        .table tr:nth-child(even) {
            background-color: #e0f2f1;
        }

        .table tr:hover {
            background-color: #b2dfdb;
            transition: background-color 0.3s ease;
        }



        
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div>
             <div class="header">
                <img src="Smartvent.jpg" alt="Smart Venture Logo" class="logo-img" />
                <div class="name">  Smart Venture</div>
             </div>
            <br /><br /><br />
            <br />
           <div class="background">
            <h2>Dashboard</h2>

            <div class="dashboard-box">
                <asp:TextBox ID="Totalusers" runat="server" CssClass="stat" ReadOnly="true" />
                <asp:TextBox ID="Admin" runat="server" CssClass="stat" ReadOnly="true" />
                <asp:TextBox ID="Teacher" runat="server" CssClass="stat" ReadOnly="true" />
                <asp:TextBox ID="Student" runat="server" CssClass="stat" ReadOnly="true" />
            </div>

            <div class="grid-style">
                <asp:GridView ID="GridViewAccounts" runat="server" AutoGenerateColumns="False" CssClass="table" GridLines="Both" BorderStyle="Solid" BorderColor="#ccc" OnSelectedIndexChanged="GridViewAccounts_SelectedIndexChanged">
                    <HeaderStyle BackColor="#00695c" Font-Bold="True" ForeColor="White" />
                    <RowStyle Font-Size="18px" />
                    <Columns>
                        <asp:BoundField DataField="fname" HeaderText="First Name" />
                        <asp:BoundField DataField="lname" HeaderText="Last Name" />
                        <asp:BoundField DataField="age" HeaderText="Age" />
                        <asp:BoundField DataField="gender" HeaderText="Gender" />
                        <asp:BoundField DataField="email" HeaderText="Email" />
                        <asp:BoundField DataField="username" HeaderText="Username" />
                        <asp:BoundField DataField="role" HeaderText="Role" />
                        <asp:TemplateField HeaderText="Edit">
                            <ItemTemplate>
                                <asp:HyperLink ID="EditLink" runat="server" NavigateUrl='<%# "manageUser.aspx?username=" + Eval("username") %>'>Edit</asp:HyperLink>
                            </ItemTemplate>
                        </asp:TemplateField>
                    </Columns>
                </asp:GridView>
              </div>

        </div>
        </div>
        <div class="footer">
            <p>&copy; 2025 Smart Venture. All rights reserved.</p>
        </div>
    </form>
</body>
</html>