﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment
{
    public partial class adminDashboard2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            con.Open();

            if (!Page.IsPostBack)
            {
                // Total users
                SqlCommand countUsersCmd = new SqlCommand("SELECT COUNT(username) FROM accountTable", con);
                int totalUsers = (int)countUsersCmd.ExecuteScalar();
                Totalusers.Text = "Total Users: " + totalUsers;

                // Admins
                SqlCommand countAdminCmd = new SqlCommand("SELECT COUNT(*) FROM accountTable WHERE role = 'Admin'", con);
                int totalAdmin = (int)countAdminCmd.ExecuteScalar();
                Admin.Text = "Total Admin: " + totalAdmin;

                // Teachers
                SqlCommand countTeacherCmd = new SqlCommand("SELECT COUNT(*) FROM accountTable WHERE role = 'Teacher'", con);
                int totalTeacher = (int)countTeacherCmd.ExecuteScalar();
                Teacher.Text = "Total Teacher: " + totalTeacher;

                // Students
                SqlCommand countStudentCmd = new SqlCommand("SELECT COUNT(*) FROM accountTable WHERE role = 'Student'", con);
                int totalStudent = (int)countStudentCmd.ExecuteScalar();
                Student.Text = "Total Student: " + totalStudent;

                // Load account table to display
                LoadAccountTable(con);
            }

            con.Close();
            }

            private void LoadAccountTable(SqlConnection con)
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM accountTable", con);
                SqlDataReader reader = cmd.ExecuteReader();
                GridViewAccounts.DataSource = reader;
                GridViewAccounts.DataBind();
                reader.Close();
            }

       
    }
}